﻿
namespace ZCRMSDK.CRM.Library.Common
{
    public abstract class ZCRMEntity { }
}
